1.整个目录剪切到C:\
2.管理员运行 cmd cd 到 office 2021 LTSC目录
3.运行 setup.exe /configure configuration.xml
4.开始安装

注意：下载的配置文件为 配置.xml ，需更改为 configuration.xml 否则将无法找到文件

——————————
2021 LTSC 配置需求：
CPU：1.6GHz、双核处理器及以上配置；
内存：32 位 Office 需要 2GB；64 位 Office 需要 4GB；
硬盘：Win 系统需要 4GB 的可用空间；
显卡：支持 DirectX 10 显卡及硬件加速；
分辨率：至少 1280*768 2.